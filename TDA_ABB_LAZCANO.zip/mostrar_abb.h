#ifndef MOSTRAR_ABB_H_
#define MOSTRAR_ABB_H_

#include "src/abb.h"

#define MAX_ARBOL 1500

void mostrar_abb(abb_t* abb, void (*formateador)(void*));

#endif // MOSTRAR_ABB_H_
